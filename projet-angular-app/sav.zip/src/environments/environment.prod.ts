export const environment = {

  production: true,
  
  firebase: {
    apiKey: 'AIzaSyDMMdUNmECtD01wJzzAJHP-PKYUFYBU-QQ',  
    authDomain: 'projetangularicc.firebaseapp.com',  
    databaseURL: 'https://projetangularicc.firebaseio.com',  
    projectId: 'projetangularicc',  
    storageBucket: 'projetangularicc.appspot.com',  
    messagingSenderId: '475061426828'
  }
  };
