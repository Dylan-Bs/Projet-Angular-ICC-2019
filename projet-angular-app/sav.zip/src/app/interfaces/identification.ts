export interface Identification {
    email:string;
    password:string;
    nom?:string;
    prenom?:string;
}
