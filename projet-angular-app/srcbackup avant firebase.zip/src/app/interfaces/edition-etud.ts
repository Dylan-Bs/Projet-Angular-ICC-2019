export interface EditionEtud {
}
