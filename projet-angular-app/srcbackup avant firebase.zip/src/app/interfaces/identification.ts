export interface Identification {
    email:string;
    pwd:string;
    nom?:string;
    prenom?:string;
}
