import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gestion-des-comptes',
  templateUrl: './gestion-des-comptes.component.html',
  styleUrls: ['./gestion-des-comptes.component.css']
})
export class GestionDesComptesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
