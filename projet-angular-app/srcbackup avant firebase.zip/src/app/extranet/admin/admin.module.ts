import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GestionDesComptesComponent } from './gestion-des-comptes/gestion-des-comptes.component';



@NgModule({
  declarations: [GestionDesComptesComponent],
  imports: [
    CommonModule
  ]
})
export class AdminModule { }
