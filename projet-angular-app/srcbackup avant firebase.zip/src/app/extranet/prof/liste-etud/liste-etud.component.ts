import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-liste-etud',
  templateUrl: './liste-etud.component.html',
  styleUrls: ['./liste-etud.component.css']
})
export class ListeEtudComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
