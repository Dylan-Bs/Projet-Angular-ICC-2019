import { Component, OnInit } from '@angular/core';
import { Identification } from '../interfaces/identification';
import { ConnexionService } from '../services/connexion.service';

@Component({
  selector: 'app-connexion',
  templateUrl: './connexion.component.html',
  styleUrls: ['./connexion.component.css']
})
export class ConnexionComponent implements OnInit {

  identification:Identification;

  constructor(public conne:ConnexionService) { }

  ngOnInit() {
    this.identification={
      email:'',
      pwd:'',
    }
  }

  desTrucsDansLaConsole(){
    console.log(this.identification);
  }

  authentification(){
    this.conne.connecte = true;
    console.log("tentative d'authentification");
  }
}
