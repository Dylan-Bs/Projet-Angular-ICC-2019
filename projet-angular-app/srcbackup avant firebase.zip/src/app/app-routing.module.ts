import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccueilComponent } from './accueil/accueil.component';
import { CollecteComponent } from './collecte/collecte.component';
import { RgpdComponent } from './rgpd/rgpd.component';
import { ConnexionComponent } from './connexion/connexion.component';
// import { AuthGuard } from './services/auth.guard';
import { Erreur404Component } from './erreur404/erreur404.component';


const routes: Routes = [
  {path:'', component:AccueilComponent},
  {path:'formulaire', component:CollecteComponent},
  {path:'rgpd', component:RgpdComponent},
  {path:'connexion', component:ConnexionComponent},
  {path:'**', component:Erreur404Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
