import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collecte',
  templateUrl: './collecte.component.html',
  styleUrls: ['./collecte.component.css']
})
export class CollecteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
